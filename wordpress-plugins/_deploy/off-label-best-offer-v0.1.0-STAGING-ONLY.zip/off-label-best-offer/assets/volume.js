(function () {
  'use strict';
  var money = window.olrOfferMoney || {symbol: '$', decimals: 2, decimal: '.', thousand: ',', format: '%1$s%2$s'};
  var decoder = document.createElement('textarea');
  decoder.innerHTML = money.symbol;
  function price(value) {
    var parts = Number(value).toFixed(Number(money.decimals)).split('.');
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, money.thousand);
    return money.format.replace('%1$s', decoder.value).replace('%2$s', parts.join(money.decimal));
  }
  function text(tag, className, content) {
    var node = document.createElement(tag);
    node.className = className;
    node.textContent = content;
    return node;
  }
  function init(root) {
    var selector = root.querySelector('[data-olr-offer]');
    if (!selector || selector.dataset.offerReady) return;
    selector.dataset.offerReady = 'yes';
    var initial;
    try { initial = JSON.parse(selector.dataset.olrOffer); } catch (e) { return; }
    var data = initial;
    var queued = false;
    var observer = new MutationObserver(schedule);
    function schedule() {
      if (queued) return;
      queued = true;
      Promise.resolve().then(function () { queued = false; render(); });
    }
    function render() {
      observer.disconnect();
      selector.classList.add('olr-volume-offers');
      selector.querySelectorAll('[data-olr-quantity]').forEach(function (button) {
        var qty = Number(button.dataset.olrQuantity);
        var rate = 0;
        if (data.enabled) data.tiers.slice().sort(function (a, b) { return a.quantity - b.quantity; }).forEach(function (tier) {
          if (qty >= tier.quantity) rate = tier.percent;
        });
        var unit = Math.min(data.current, data.regular * (1 - rate / 100));
        var effective = data.regular > 0 ? Math.max(0, 100 * (1 - unit / data.regular)) : 0;
        button.replaceChildren(text('span', 'olr-tier-title', qty + (qty === 1 ? ' BOTTLE' : ' BOTTLES')));
        if (data.variable) {
          button.append(text('strong', 'olr-tier-total', 'SELECT STRENGTH'));
          return;
        }
        // First strong remains the total: the existing bridge may update it; the observer restores this quote.
        button.append(text('strong', 'olr-tier-total', price(unit * qty) + ' TOTAL'));
        if (effective > 0) {
          button.append(text('span', 'olr-tier-saving', 'SAVE ' + Number(effective.toFixed(2)) + '%'));
          button.append(text('del', 'olr-tier-regular', price(data.regular * qty)));
        } else button.append(text('span', 'olr-tier-saving', 'REGULAR PRICE'));
        button.append(text('span', 'olr-tier-unit', price(unit) + ' / BOTTLE'));
        if (qty === 10 && effective > 0) button.append(text('span', 'olr-tier-badge', 'BEST VALUE'));
      });
      if (!selector.querySelector('.olr-volume-policy')) selector.append(text('p', 'olr-volume-policy', 'Volume savings applied automatically. Offers cannot be combined. Highest eligible discount applies.'));
      observer.observe(selector, {subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ['data-unit-price']});
    }
    var form = root.querySelector('form.variations_form');
    if (form && window.jQuery) {
      window.jQuery(form).on('found_variation.olrOffer', function (event, variation) {
        data = variation.olr_offer || initial;
        schedule();
      }).on('reset_data.olrOffer hide_variation.olrOffer', function () { data = initial; schedule(); });
    }
    render();
  }
  function start() { document.querySelectorAll('.olr-product-view').forEach(init); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
}());
