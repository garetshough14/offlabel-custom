<?php
/**
 * Plugin Name: Off Label Test Page Seeder
 * Description: Creates isolated GitPress-managed test pages for the Off Label production rollout.
 * Version: 1.0.1
 * Author: Off Label Research
 * Text Domain: off-label-test-page-seeder
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class OLR_Test_Page_Seeder {
	const MARKER_META = '_olr_test_page_seeder';
	const VERSION     = '1.0.1';

	/**
	 * Return the complete isolated test-page map.
	 *
	 * @return array<string,array<string,string>>
	 */
	public static function pages() {
		return array(
			'home-test' => array(
				'title'    => 'Home Test',
				'fragment' => 'home.html',
			),
			'about-test' => array(
				'title'    => 'About Test',
				'fragment' => 'about.html',
			),
			'research-catalog-test' => array(
				'title'    => 'Research Catalog Test',
				'fragment' => 'research.html',
			),
			'research-item' => array(
				'title'    => 'Research Item Test',
				'fragment' => 'product.html',
			),
			'testing-test' => array(
				'title'    => 'Testing and COAs Test',
				'fragment' => 'testing.html',
			),
			'receipt-test' => array(
				'title'    => 'COA Receipt Test',
				'fragment' => 'receipt.html',
			),
			'faq-test' => array(
				'title'    => 'FAQ Test',
				'fragment' => 'faq.html',
			),
			'cart-test' => array(
				'title'    => 'Cart Test',
				'fragment' => 'cart.html',
			),
			'build-your-box-test' => array(
				'title'    => 'Build Your Box Test',
				'fragment' => 'build-your-box.html',
			),
			'checkout-test' => array(
				'title'    => 'Checkout Test',
				'fragment' => 'checkout-test.html',
			),
			'account-test' => array(
				'title'    => 'Account Test',
				'fragment' => 'account.html',
			),
			'affiliate-test' => array(
				'title'    => 'Affiliate Program Test',
				'fragment' => 'affiliate.html',
			),
			'affiliate-guidelines-test' => array(
				'title'    => 'Affiliate Guidelines Test',
				'fragment' => 'affiliate-guidelines.html',
			),
		);
	}

	/**
	 * Build the GitPress source shortcode for a fragment.
	 *
	 * @param string $fragment Fragment filename.
	 * @return string
	 */
	private static function source_shortcode( $fragment ) {
		return sprintf(
			'[divi_github_content owner="garetshough14" repo="offlabel-custom" path="gitpress/pages/%s" branch="main" format="html" updated_meta="false"]',
			$fragment
		);
	}

	/**
	 * Create missing test pages and repair their GitPress settings.
	 * Existing production routes are not part of this map and are never touched.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	public static function seed() {
		$results = array();

		foreach ( self::pages() as $slug => $definition ) {
			$page    = get_page_by_path( $slug, OBJECT, 'page' );
			$created = false;

			if ( ! $page || 'trash' === $page->post_status ) {
				$page_id = wp_insert_post(
					array(
						'post_title'     => $definition['title'],
						'post_name'      => $slug,
						'post_type'      => 'page',
						'post_status'    => 'publish',
						'post_content'   => '',
						'comment_status' => 'closed',
						'ping_status'    => 'closed',
					),
					true
				);

				if ( is_wp_error( $page_id ) ) {
					$results[ $slug ] = array(
						'ok'      => false,
						'message' => $page_id->get_error_message(),
					);
					continue;
				}

				$created = true;
			} else {
				$page_id = (int) $page->ID;

				if ( 'publish' !== $page->post_status ) {
					$published = wp_update_post(
						array(
							'ID'          => $page_id,
							'post_status' => 'publish',
						),
						true
					);

					if ( is_wp_error( $published ) ) {
						$results[ $slug ] = array(
							'ok'      => false,
							'message' => $published->get_error_message(),
						);
						continue;
					}
				}
			}

			$shortcode = self::source_shortcode( $definition['fragment'] );

			update_post_meta( $page_id, 'dgs_page_shortcode', $shortcode );
			update_post_meta( $page_id, 'dgs_page_shortcode_render_mode', 'gitpress_managed' );
			update_post_meta( $page_id, 'dgs_page_shortcode_placement', 'after' );
			update_post_meta( $page_id, 'dgs_page_shortcode_full_width', '1' );
			update_post_meta( $page_id, self::MARKER_META, self::VERSION );

			$results[ $slug ] = array(
				'ok'      => true,
				'id'      => $page_id,
				'created' => $created,
				'url'     => get_permalink( $page_id ),
			);
		}

		update_option( 'olr_test_page_seeder_last_run', time(), false );
		return $results;
	}

	/** Seed immediately when the plugin is activated. */
	public static function activate() {
		self::seed();
		flush_rewrite_rules( false );
	}

	/** Register runtime and administration hooks. */
	public static function init() {
		add_filter( 'wp_robots', array( __CLASS__, 'noindex_test_pages' ) );
		add_filter( 'body_class', array( __CLASS__, 'body_classes' ) );
		add_action( 'admin_menu', array( __CLASS__, 'admin_menu' ) );
		add_action( 'admin_post_olr_seed_test_pages', array( __CLASS__, 'handle_seed_request' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( __CLASS__, 'plugin_action_links' ) );
	}

	/** Determine whether the current request is one of the isolated test pages. */
	private static function is_test_page() {
		return ! is_admin() && is_page( array_keys( self::pages() ) );
	}

	/**
	 * Keep test routes out of search engines.
	 *
	 * @param array<string,bool> $robots Existing directives.
	 * @return array<string,bool>
	 */
	public static function noindex_test_pages( $robots ) {
		if ( self::is_test_page() ) {
			$robots['noindex']  = true;
			$robots['nofollow'] = true;
		}
		return $robots;
	}

	/**
	 * Add stable test-page classes without affecting production pages.
	 *
	 * @param string[] $classes Existing body classes.
	 * @return string[]
	 */
	public static function body_classes( $classes ) {
		if ( self::is_test_page() ) {
			$classes[] = 'olr-isolated-test-page';
		}
		return $classes;
	}

	/** Add the seeder status page under Tools. */
	public static function admin_menu() {
		add_management_page(
			__( 'Off Label Test Pages', 'off-label-test-page-seeder' ),
			__( 'Off Label Test Pages', 'off-label-test-page-seeder' ),
			'manage_options',
			'olr-test-pages',
			array( __CLASS__, 'render_admin_page' )
		);
	}

	/**
	 * Add a direct link from the Plugins screen.
	 *
	 * @param string[] $links Existing links.
	 * @return string[]
	 */
	public static function plugin_action_links( $links ) {
		array_unshift(
			$links,
			'<a href="' . esc_url( admin_url( 'tools.php?page=olr-test-pages' ) ) . '">' . esc_html__( 'Test Pages', 'off-label-test-page-seeder' ) . '</a>'
		);
		return $links;
	}

	/** Handle the nonce-protected repair action. */
	public static function handle_seed_request() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to manage test pages.', 'off-label-test-page-seeder' ) );
		}
		check_admin_referer( 'olr_seed_test_pages' );
		self::seed();
		wp_safe_redirect( add_query_arg( 'seeded', '1', admin_url( 'tools.php?page=olr-test-pages' ) ) );
		exit;
	}

	/** Render the page inventory and repair control. */
	public static function render_admin_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Off Label Test Pages', 'off-label-test-page-seeder' ); ?></h1>
			<p><?php esc_html_e( 'These published, noindex routes mirror the GitPress fragments planned for production without changing any live page.', 'off-label-test-page-seeder' ); ?></p>
			<?php if ( isset( $_GET['seeded'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'The test-page set was created or repaired.', 'off-label-test-page-seeder' ); ?></p></div>
			<?php endif; ?>
			<table class="widefat striped">
				<thead><tr><th><?php esc_html_e( 'Page', 'off-label-test-page-seeder' ); ?></th><th><?php esc_html_e( 'Slug', 'off-label-test-page-seeder' ); ?></th><th><?php esc_html_e( 'Fragment', 'off-label-test-page-seeder' ); ?></th><th><?php esc_html_e( 'Status', 'off-label-test-page-seeder' ); ?></th><th><?php esc_html_e( 'Actions', 'off-label-test-page-seeder' ); ?></th></tr></thead>
				<tbody>
				<?php foreach ( self::pages() as $slug => $definition ) : ?>
					<?php $page = get_page_by_path( $slug, OBJECT, 'page' ); ?>
					<tr>
						<td><?php echo esc_html( $definition['title'] ); ?></td>
						<td><code><?php echo esc_html( $slug ); ?></code></td>
						<td><code><?php echo esc_html( $definition['fragment'] ); ?></code></td>
						<td><?php echo $page ? esc_html( ucfirst( $page->post_status ) ) : esc_html__( 'Missing', 'off-label-test-page-seeder' ); ?></td>
						<td>
							<?php if ( $page ) : ?>
								<a href="<?php echo esc_url( get_permalink( $page ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'View', 'off-label-test-page-seeder' ); ?></a>
								&nbsp;|&nbsp;
								<a href="<?php echo esc_url( get_edit_post_link( $page->ID ) ); ?>"><?php esc_html_e( 'Edit', 'off-label-test-page-seeder' ); ?></a>
							<?php else : ?>
								&mdash;
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top: 20px;">
				<input type="hidden" name="action" value="olr_seed_test_pages">
				<?php wp_nonce_field( 'olr_seed_test_pages' ); ?>
				<?php submit_button( __( 'Create or repair test pages', 'off-label-test-page-seeder' ), 'primary', 'submit', false ); ?>
			</form>
		</div>
		<?php
	}
}

register_activation_hook( __FILE__, array( 'OLR_Test_Page_Seeder', 'activate' ) );
add_action( 'plugins_loaded', array( 'OLR_Test_Page_Seeder', 'init' ) );
